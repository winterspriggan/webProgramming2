package jpa;

import jpa.PostDTO;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;

import javax.persistence.Entity;

@Getter
@Setter
@Entity
@Table(name = "Post")
@NoArgsConstructor
@AllArgsConstructor
public class Post {



    public Post(PostDTO postDTO) {
        this.setId(postDTO.getId());
        this.setTitle(postDTO.getTitle());
        this.setContent(postDTO.getContent());

}


    @Id
    @Column(name = "ID")
    private Long id;
    @Column(name = "TITLE")
    private String title;
    @Column(name = "CONTENT")
    private String content;
}
