package ddinggeunmarket_service.example.ddinggeunmarket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DDinggeunMarketApplicationTests {

    @Test
    void contextLoads() {
    }

}
