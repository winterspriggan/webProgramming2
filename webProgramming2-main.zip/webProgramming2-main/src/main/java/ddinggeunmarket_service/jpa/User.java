package ddinggeunmarket_service.jpa;


import ddinggeunmarket_service.jpa.MyPage.Item;
import ddinggeunmarket_service.jpa.MyPage.Purchase;
import ddinggeunmarket_service.jpa.MyPage.Sale;
import ddinggeunmarket_service.jpa.MyPage.WishList;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name ="user_table")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "age")
    private int age;

    @Column(name = "password")
    private String password;

    @Column(name = "phoneNumb")
    private String phoneNumb;

    @Column(name = "dob")
    private String dob;

    @Column(name = "email")
    private String email;

    @Column(name = "address")
    private String address;

    @OneToMany(mappedBy = "buyer")
    private List<Purchase> purchase;

    @OneToMany(mappedBy = "seller")
    private List<Sale> sale;

    @OneToMany(mappedBy = "user")
    private List<WishList> interestItems;
}
