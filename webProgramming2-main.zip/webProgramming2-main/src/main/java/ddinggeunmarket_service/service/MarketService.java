package ddinggeunmarket_service.service;

public interface MarketService {
}
