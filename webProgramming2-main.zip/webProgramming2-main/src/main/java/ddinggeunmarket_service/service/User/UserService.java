package ddinggeunmarket_service.service.User;

import ddinggeunmarket_service.jpa.User;

import java.util.List;

public interface UserService {
    User createUser(User user);
    List<User> getAllUsers();
    User getUserById(Long userId);
    User updateUser(Long userId, User updatedUser);
    boolean deleteUser(Long userId);
}
