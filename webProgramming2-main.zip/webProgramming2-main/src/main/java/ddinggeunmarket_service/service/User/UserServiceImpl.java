package ddinggeunmarket_service.service.User;

import ddinggeunmarket_service.jpa.MyPage.Item;
import ddinggeunmarket_service.jpa.MyPage.ItemRepository;
import ddinggeunmarket_service.jpa.MyPage.WishList;
import ddinggeunmarket_service.jpa.MyPage.WishListRepository;
import ddinggeunmarket_service.jpa.User;
import ddinggeunmarket_service.jpa.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private ItemRepository itemRepository;
    @Autowired
    private WishListRepository wishListRepository;

    @Override
    public User createUser(User user) {
        // 사용자 생성 로직 구현
        return userRepository.save(user);
    }

    @Override
    public List<User> getAllUsers() {
        // 모든 사용자 조회 로직 구현
        return (List<User>) userRepository.findAll();
    }

    @Override
    public User getUserById(Long userId) {
        // 특정 사용자 조회 로직 구현
        Optional<User> optionalUser = userRepository.findById(userId);
        return optionalUser.orElse(null);
    }

    @Override
    public User updateUser(Long userId, User updatedUser) {
        // 특정 사용자 업데이트 로직 구현
        Optional<User> optionalUser = userRepository.findById(userId);
        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            // 업데이트 로직 구현
            user.setName(updatedUser.getName());
            user.setAge(updatedUser.getAge());
            // 나머지 필드도 업데이트
            return userRepository.save(user);
        } else {
            return null;
        }
    }
    @Override
    public boolean deleteUser(Long userId) {
        Optional<User> optionalUser = userRepository.findById(userId);
        if (optionalUser.isPresent()) {
            userRepository.deleteById(userId);
            return true;
        } else {
            return false;
        }
    }
    public void addWishList(Long userId, Long itemId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found with id: " + userId));

        Item item = itemRepository.findById(itemId)
                .orElseThrow(() -> new IllegalArgumentException("Item not found with id: " + itemId));


        WishList wishList = new WishList();
        wishList.setUser(user);
        wishList.setItem(item);

        wishListRepository.save(wishList);
    }

}
