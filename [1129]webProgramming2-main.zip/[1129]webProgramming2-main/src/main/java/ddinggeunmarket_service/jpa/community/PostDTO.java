package ddinggeunmarket_service.jpa.community;

import lombok.Data;

@Data
public class PostDTO {
    private Long id;
    private String title;
    private String content;
}
