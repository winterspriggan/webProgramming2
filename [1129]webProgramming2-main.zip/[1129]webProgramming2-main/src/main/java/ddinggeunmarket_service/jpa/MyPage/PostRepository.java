package ddinggeunmarket_service.jpa.MyPage;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PostRepository extends JpaRepository<Post, Long> {
    List<oracle.jdbc.proxy.annotation.Post> findByCategoryAndUserId(String category, Long userId);
    List<oracle.jdbc.proxy.annotation.Post> findByUserId(Long userId);
}
