package ddinggeunmarket_service.jpa.MyPage;

import ddinggeunmarket_service.jpa.user.User;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
@Getter
@Setter
@Entity
public class Item {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String itemName;

    @ManyToMany(mappedBy = "wishList")
    private List<User> wishingUsers;

    // 추가: Item의 설명과 가격
    private String description;
    private double price;

    // Getter와 Setter 메소드 추가
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}