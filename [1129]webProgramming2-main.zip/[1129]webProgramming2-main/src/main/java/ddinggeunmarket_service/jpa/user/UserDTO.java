package ddinggeunmarket_service.jpa.user;


import lombok.Data;

@Data
public class UserDTO {

//    public UserDTO(int id, String password, String phoneNumb, String dob, String email, String address, String name, int age) {
//        this.setId(id);
//        this.setPassword(password);
//        this.setPhoneNumb(phoneNumb);
//        this.setDob(dob);
//        this.setEmail(email);
//        this.setAddress(address);
//        this.setName(name);
//        this.setAge(age);
//    }

    private String id;
    private String phoneNumb;
    private String password;
    private String dob;
    private String email;
    private String address;
    private String name;
    private int age;
//    private List<Wishlist> wishlist;

}
