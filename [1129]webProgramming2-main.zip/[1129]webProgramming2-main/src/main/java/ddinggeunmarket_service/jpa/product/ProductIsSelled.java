package ddinggeunmarket_service.jpa.product;

public enum ProductIsSelled {
    SELLED, UNSELLED
}
