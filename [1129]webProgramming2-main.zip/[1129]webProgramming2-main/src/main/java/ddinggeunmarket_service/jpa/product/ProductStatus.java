package ddinggeunmarket_service.jpa.product;

public enum ProductStatus {
     GOOD , SOSO , BAD
}
