package ddinggeunmarket_service.jpa.product;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class productForm {
    private String name;
    private int price;
    private String status;
    private String trade;
}
