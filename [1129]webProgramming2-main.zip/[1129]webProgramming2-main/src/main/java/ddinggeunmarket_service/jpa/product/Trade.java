package ddinggeunmarket_service.jpa.product;

public enum Trade {
    MEET , DELIVERY
}
