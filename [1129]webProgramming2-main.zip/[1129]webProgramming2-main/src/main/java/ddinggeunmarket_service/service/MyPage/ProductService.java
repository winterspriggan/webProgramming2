package ddinggeunmarket_service.service.MyPage;

import ddinggeunmarket_service.jpa.MyPage.Product;

import java.util.List;

public interface ProductService {
    Product getProductById(Long productId);
    List<Product> getProductsByCategory(String category);

}
