package ddinggeunmarket_service.service.MyPage;

import ddinggeunmarket_service.jpa.MyPage.Comment;

import java.util.List;

public interface CommentService {
    List<Comment> getMyComments(Long userId);
}
