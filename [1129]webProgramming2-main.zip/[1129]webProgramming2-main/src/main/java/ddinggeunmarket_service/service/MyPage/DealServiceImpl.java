package ddinggeunmarket_service.service.MyPage;

import ddinggeunmarket_service.jpa.MyPage.Deal;
import ddinggeunmarket_service.jpa.MyPage.DealRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DealServiceImpl implements DealService {

    @Autowired
    private DealRepository dealRepository;

    @Override
    public List<Deal> getSalesHistory(Long userId) {
        return dealRepository.findBySellerId(userId);
    }

    @Override
    public List<Deal> getPurchaseHistory(Long userId) {
        return dealRepository.findByBuyerId(userId);
    }
}
