package ddinggeunmarket_service.service.MyPage;

import ddinggeunmarket_service.jpa.MyPage.Deal;

import java.util.List;

public interface DealService {
    List<Deal> getSalesHistory(Long userId);
    List<Deal> getPurchaseHistory(Long userId);

}
