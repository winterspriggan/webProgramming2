package ddinggeunmarket_service.service.MyPage;

import ddinggeunmarket_service.jpa.MyPage.Comment;
import ddinggeunmarket_service.jpa.MyPage.CommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CommentServiceImpl implements CommentService {

    @Autowired
    private CommentRepository commentRepository;

    @Override
    public List<Comment> getMyComments(Long userId) {
        return commentRepository.findByUserId(userId);
    }
}